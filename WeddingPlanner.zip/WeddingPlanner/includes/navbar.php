<link rel="stylesheet" type="text/css" href="navbar.css">

<nav class="navbar">
    <div class="container-fluid">
        <ul class="nav navbar-nav">
            <li class="active"><a href="#">Clientes</a></li>
            <li><a href="#">Eventos</a></li>
            <li><a href="#">Servicios</a></li>
            <li><a href="#">Empresas</a></li>
        </ul>
    </div>
</nav>