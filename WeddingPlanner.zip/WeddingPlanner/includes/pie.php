<footer class="section">
    <div class="center grey-text">Copyright 2020 CCB</div>

</footer>
<div class="clear"></div>
