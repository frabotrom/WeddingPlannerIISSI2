<style>
    /* Style the top navigation bar */
    .topnav {
    overflow: hidden;
    background-color: #333;
    }

    /* Style the topnav links */
    .topnav a {
    float: left;
    display: block;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    }

    /* Change color on hover */
    .topnav a:hover {
    background-color: #ddd;
    color: black;
    }

</style>

<div class="topnav">
    <a href="../src/empleado/listEmpleado.php">Empleados</a>
    <a href="../src/cliente/listCliente.php">Clientes</a>
    <a href="#">Eventos</a>
    <a href="#">Servicios</a>
    <a href="../src/empresa/listEmpresa.php">Empresas</a>
</div>
