/* Empleados */

CREATE OR REPLACE PROCEDURE MODIFICAR_EMPLEADO
(w_id IN empleados.id%TYPE,
 w_nombre IN empleados.nombre%TYPE,
 w_apellidos IN empleados.apellidos%TYPE,
 w_dni IN empleados.dni%TYPE,
 w_telefono IN empleados.telefono%TYPE,
 w_correo IN empleados.correo%TYPE,
 w_usuario IN empleados.usuario%TYPE,
 w_contrasena IN empleados.contrasena%TYPE,
 w_es_administrador IN empleados.es_administrador%TYPE) IS
BEGIN
  UPDATE empleados SET nombre=w_nombre, apellidos=w_apellidos, dni = w_dni,
  telefono=w_telefono, correo=w_correo, usuario=w_usuario, contrasena=w_contrasena,
  es_administrador=w_es_administrador WHERE id = w_id;
END;
/

CREATE OR REPLACE PROCEDURE CREAR_EMPLEADO
(w_nombre IN empleados.nombre%TYPE,
 w_apellidos IN empleados.apellidos%TYPE,
 w_dni IN empleados.dni%TYPE,
 w_telefono IN empleados.telefono%TYPE,
 w_correo IN empleados.correo%TYPE,
 w_usuario IN empleados.usuario%TYPE,
 w_contrasena IN empleados.contrasena%TYPE,
 w_es_administrador IN empleados.es_administrador%TYPE) IS
BEGIN
  INSERT INTO empleados (nombre, apellidos, dni, telefono, correo, usuario, contrasena, es_administrador)
VALUES (w_nombre, w_apellidos, w_dni, w_telefono, w_correo, w_usuario, w_contrasena, w_es_administrador); 
END;
/

CREATE OR REPLACE PROCEDURE ELIMINAR_EMPLEADO
(w_id IN empleados.id%TYPE) IS
BEGIN
  DELETE FROM empleados WHERE id=w_id;
END;
/

/*Empresas*/

CREATE OR REPLACE PROCEDURE MODIFICAR_EMPRESA
(w_id IN empresas.id%TYPE,
 w_nombre IN empresas.nombre%TYPE,
 w_telefono IN empresas.telefono%TYPE,
 w_correo IN empresas.correo%TYPE,
 w_direccion IN empresas.direccion%TYPE) IS
BEGIN
  UPDATE empresas SET nombre=w_nombre, telefono=w_telefono, correo=w_correo, direccion=w_direccion 
  WHERE id = w_id;
END;
/

CREATE OR REPLACE PROCEDURE CREAR_EMPRESA
(w_id IN empresas.id%TYPE,
 w_nombre IN empresas.nombre%TYPE,
 w_telefono IN empresas.telefono%TYPE,
 w_correo IN empresas.correo%TYPE,
 w_direccion IN empresas.direccion%TYPE) IS
BEGIN
  INSERT INTO empresas (nombre, telefono, correo, direccion)
VALUES (w_nombre, w_telefono, w_correo, w_direccion); 
END;
/

CREATE OR REPLACE PROCEDURE ELIMINAR_EMPRESA
(w_id IN empresas.id%TYPE) IS
BEGIN
  DELETE FROM empresas WHERE id=w_id;
END;
/

/*Clientes*/

CREATE OR REPLACE PROCEDURE ELIMINAR_CLIENTE  
(w_id IN clientes.id%TYPE) IS
BEGIN
  DELETE FROM clientes WHERE id=w_id;
END;
/

CREATE OR REPLACE PROCEDURE MODIFICAR_CLIENTE
(w_id IN clientes.id%TYPE,
 w_nombre IN clientes.nombre%TYPE,
 w_apellidos IN clientes.apellidos%TYPE,
 w_dni IN clientes.dni%TYPE,
 w_telefono IN clientes.telefono%TYPE,
 w_correo IN clientes.correo%TYPE,
 w_direccion IN clientes.direccion%TYPE,
 
 w_id_empleado IN clientes.id_empleado%TYPE) IS
BEGIN
  UPDATE clientes SET nombre=w_nombre, apellidos=w_apellidos, dni = w_dni,
  telefono=w_telefono, correo=w_correo, direccion=w_direccion, 
  id_empleado=w_id_empleado WHERE id = w_id;
END;
/
CREATE OR REPLACE PROCEDURE CREAR_CLIENTE
(w_nombre IN clientes.nombre%TYPE,
 w_apellidos IN clientes.apellidos%TYPE,
 w_dni IN clientes.dni%TYPE,
 w_telefono IN clientes.telefono%TYPE,
 w_correo IN clientes.correo%TYPE,
 w_direccion IN clientes.direccion%TYPE,
 w_id_empleado IN clientes.id_empleado%TYPE) IS
BEGIN
  INSERT INTO clientes (nombre, apellidos, dni, telefono, correo, direccion, id_empleado)
VALUES (w_nombre, w_apellidos, w_dni, w_telefono, w_correo, w_direccion,  w_id_empleado); 
END;
/
