<?php

function totalConsulta($conn, $query)
{
    try {
        $total_consulta = "SELECT COUNT(*) AS TOTAL FROM ($query)";

        $stmt = $conn->query($total_consulta);
        $result = $stmt->fetch();
        $total = $result['TOTAL'];
        return $total;
    } catch (PDOException $e) {
        //TODO: Crear página de error
//        $_SESSION['excepcion'] = $e->GetMessage();
//        header("Location: error.php");
    }
}

function consultaPaginada($conn, $query, $pag_num, $pag_size)
{
    try {
        $primera = ($pag_num - 1) * $pag_size + 1;
        $ultima = $pag_num * $pag_size;
        $consulta_paginada = "SELECT * FROM ( "
            . "SELECT ROWNUM RNUM, AUX.* FROM ($query) AUX "
            . "WHERE ROWNUM <= :ultima"
            . ") "
            . "WHERE RNUM >= :primera";

        $stmt = $conn->prepare($consulta_paginada);
        $stmt->bindParam(':primera', $primera);
        $stmt->bindParam(':ultima', $ultima);
        $stmt->execute();
        return $stmt;
    } catch (PDOException $e) {
        //TODO: Crear página de error
//        $_SESSION['excepcion'] = $e->GetMessage();
//        header("Location: error.php");
    }
}

function gestionarPaginacion($conexion, $query)
{
    //Comprobamos si accedemos por primera vez o se debe a un cambio en la paginación
    if (isset($_SESSION["paginacion"])) {
        $paginacion = $_SESSION["paginacion"];
    }

    $paginaSeleccionada = isset($_GET["numPagina"]) ? (int)$_GET["numPagina"] : (isset($paginacion) ? (int)$paginacion["numPagina"] : 1);
    $tamPagina = isset($_GET["tamPagina"]) ? (int)$_GET["tamPagina"] : (isset($paginacion) ? (int)$paginacion["tamPagina"] : 5);

    if ($paginaSeleccionada < 1)
        $paginaSeleccionada = 1;
    if ($tamPagina < 1)
        $tamPagina = 5;

//Borrar los datos de sesión respecto la paginación para evitar confusión
    unset($_SESSION["paginacion"]);

    $totalElementos = totalConsulta($conexion, $query);
    $totalPaginas = (int)($totalElementos / $tamPagina);

    if ($totalElementos % $tamPagina > 0)
        $totalPaginas++;

    if ($paginaSeleccionada > $totalPaginas)
        $paginaSeleccionada = $totalPaginas;

//Se genera la nueva sesión para la paginación
    $paginacion["numPagina"] = $paginaSeleccionada;
    $paginacion["tamPagina"] = $tamPagina;
    $_SESSION["paginacion"] = $paginacion;

    $listPaginada = consultaPaginada($conexion, $query, $paginaSeleccionada, $tamPagina);

    $ret["paginaSeleccionada"] = $paginaSeleccionada;
    $ret["tamPagina"] = $tamPagina;
    $ret["totalPaginas"] = $totalPaginas;
    $ret["listPaginada"] = $listPaginada;
    $ret["totalElementos"] = $totalElementos;

    return $ret;
}

?>