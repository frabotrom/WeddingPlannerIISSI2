<?php
session_start();

include_once("../gestionBD.php");
include_once("../gestionPaginacion.php");

unset($_SESSION["cliente"]);

//Se crea la conexión a la BD
$conexion = crearConexionBD();

// Petición a la BD
$query = 'SELECT * FROM clientes ORDER BY id DESC';


$ret = gestionarPaginacion($conexion, $query);

$paginaSeleccionada = $ret["paginaSeleccionada"];
$totalPaginas = $ret["totalPaginas"];
$listClientes = $ret["listPaginada"];
$tamPagina = $ret["tamPagina"];
$totalClientes = $ret["totalElementos"];
cerrarConexionBD($conexion);
?>

<!DOCTYPE html>
<html lang="es">
<?php include_once('../includes/cabecera.php'); ?>
<?php include_once('../includes/menu.php'); ?>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Wedding Planner</title>
</head>

<body>
<main>
    <div class="row">
        <div class="centercolumn">
            <div class="card">
<form action="listCliente.php">
    <input type="submit" value="Clientes" />
</form>
<form action="../listEvento.php">
    <input type="submit" value="Eventos" />
</form>
<form action="../listServicio.php">
    <input type="submit" value="Servicios" />
</form>
<form action="../listEmpresa.php">
    <input type="submit" value="Empresas" />
</form>
<form action="../empleado/listEmpleado.php">
    <input type="submit" value="Empleados" />
</form><br>

    <form method="post" action="controladorCliente.php" style="display: flex">
        <h3>Clientes</h3>
        <button id="crear" name="crear" type="submit" class="crearFila">
            <img src="../../images/suma.png" class="crearFila" alt="Crear cliente
        " width="25"
                 height="25">
        </button>
    </form>

    <nav>

        <div id="paginacion">

            <?php

            for ($pagina = 1; $pagina <= $totalPaginas; $pagina++) {

                if ($pagina == $paginaSeleccionada) { ?>

                    <span class="current"><?php echo $pagina; ?></span>

                <?php } else { ?>

                    <a href="listCliente.php?numPagina=<?php echo $pagina; ?>&tamPagina=<?php echo $tamPagina;; ?>"><?php echo $pagina; ?></a>

                <?php } ?>
            <?php } ?>

        </div>


        <form method="get" action="listCliente.php">

            <input id="numPagina" name="numPagina" type="hidden" value="<?php echo $paginaSeleccionada ?>"/>

            Mostrando

            <input id="tamPagina" name="tamPagina" type="number"

                   min="1" max="<?php echo $totalClientes ?>"

                   value="<?php echo $totalClientes < 5 ? $totalClientes: $tamPagina ?>" autofocus="autofocus"/>

            entradas de <?php echo $totalClientes ?>

            <input type="submit" value="Cambiar">

        </form>

    </nav>

    <table width="100%">

        <tr>
            <th>Nombre</th>
            <th>DNI</th>
            <th>Teléfono</th>
            <th>Correo</th>
            <th>Dirección</th>

        </tr>

        <?php

        foreach ($listClientes as $cliente) {

            ?>
            <tr>
                <td><?php echo $cliente
            ["NOMBRE"] . " " . $cliente
            ["APELLIDOS"] ?></td>
                <td><?php echo $cliente
            ["DNI"] ?></td>
                <td><?php echo $cliente
            ["TELEFONO"] ?></td>
                <td><?php echo $cliente
            ["CORREO"] ?></td>
                <td><?php echo $cliente
            ["DIRECCION"] ?></td>

                <td>
                    <form method="post" action="controladorCliente.php">

                        <input id="ID" name="ID" type="hidden"
                               value="<?php echo $cliente["ID"] ?>">

                        <input id="NOMBRE" name="NOMBRE" type="hidden"
                               value="<?php echo $cliente["NOMBRE"] ?>">


                        <input id="APELLIDOS" name="APELLIDOS" type="hidden"
                               value="<?php echo $cliente["APELLIDOS"] ?>">

                        <input id="DNI" name="DNI" type="hidden"
                               value="<?php echo $cliente["DNI"] ?>">

                        <input id="TELEFONO" name="TELEFONO" type="hidden"
                               value="<?php echo $cliente["TELEFONO"] ?>">

                        <input id="CORREO" name="CORREO" type="hidden"
                               value="<?php echo $cliente["CORREO"] ?>">

                        <input id="DIRECCION" name="DIRECCION" type="hidden"
                               value="<?php echo $cliente["DIRECCION"] ?>">

                        <input id="ID_EMPLEADO" name="ID_EMPLEADO" type="hidden"
                               value="<?php echo $cliente["ID_EMPLEADO"] ?>">

                        <button id="editar" name="editar" type="submit" class="editarFila">
                            <img src="../../images/lapiz.png" class="editarFila" alt="Editar cliente
                        " width="25"
                                 height="25">
                        </button>

                        <button id="borrar1" name="borrar1" type="submit" class="borrarFila">
                            <img src="../../images/papelera.png" class="borrarFila" alt="Borrar cliente
                        " width="25"
                                 height="25">
                        </button>

                    </form>
                </td>
            </tr>
        <?php } ?>
    </table>
    <?php
    if(isset($_SESSION["excepcion"])) {
        foreach ($_SESSION["excepcion"] as $e){
            echo $e;
        }
        unset($_SESSION["excepcion"]);
    }
    ?>
  
</main>
</body>
</html>
