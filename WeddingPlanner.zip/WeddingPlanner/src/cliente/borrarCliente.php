<?php
session_start();


include_once("../gestionBD.php");

if (isset($_SESSION["idCliente"])) {
    try {
        $conexion = crearConexionBD();

        $query = "CALL ELIMINAR_CLIENTE(:id)";

        $stmt = $conexion->prepare($query);
        $stmt->bindParam(":id", $_SESSION["idCliente"]);
        $stmt->execute();
    } catch (PDOException $e){
        $_SESSION["excepcion"] = $e->getMessage();
        //Header("Location: error.php");
    }

    unset($_SESSION["idCliente"]);
    cerrarConexionBD($conexion);
}

Header("Location: listCliente.php");
?>
