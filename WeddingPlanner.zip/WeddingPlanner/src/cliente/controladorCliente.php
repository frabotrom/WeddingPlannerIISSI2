<?php
session_start();





if (isset($_REQUEST["editar"])) {

    $cliente["ID"] = $_REQUEST["ID"];
    $cliente["NOMBRE"] = $_REQUEST["NOMBRE"];
    $cliente["APELLIDOS"] = $_REQUEST["APELLIDOS"];
    $cliente["DNI"] = $_REQUEST["DNI"];
    $cliente["TELEFONO"] = $_REQUEST["TELEFONO"];
    $cliente["CORREO"] = $_REQUEST["CORREO"];
    $cliente["DIRECCION"] = $_REQUEST["DIRECCION"];
    $cliente["ID_EMPLEADO"] = $_REQUEST["ID_EMPLEADO"];
    


    $_SESSION["cliente"] = $cliente;

    Header("Location: formCliente.php");

} elseif (isset($_REQUEST["borrar1"])) {
    $_SESSION["idCliente"] = $_REQUEST["ID"];
    Header("Location: borrarCliente.php");

} elseif (isset($_REQUEST["crear"])) {
    Header("Location: formCliente.php");

} else {
    Header("Location: listCliente.php");
}
?>