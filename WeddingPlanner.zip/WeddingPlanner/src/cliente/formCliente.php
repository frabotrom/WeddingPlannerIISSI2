<?php
session_start();

include_once("../gestionBD.php");
include_once("../gestionPaginacion.php");
$conexion = crearConexionBD();

$queryClientes = 'SELECT * FROM clientes ORDER BY id DESC';

$ret = gestionarPaginacion($conexion, $queryClientes);

$paginaSeleccionada = $ret["paginaSeleccionada"];
$totalPaginas = $ret["totalPaginas"];
$listClientes = $ret["listPaginada"];
$tamPagina = $ret["tamPagina"];
$totalClientes= $ret["totalElementos"];

if (isset($_SESSION["cliente"]))
    $cliente = $_SESSION["cliente"];
    cerrarConexionBD($conexion);

?>

<!DOCTYPE html>
<html lang="es">
<?php include_once('../includes/cabecera.php'); ?>
<?php include_once('../includes/menu.php'); ?>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Wedding Planner</title>

    <script src="validacionFormulario.js"></script>
</head>

<body>

<main>
    <div class="row">
        <div class="centercolumn">
            <div class="card">
    <form name="formCliente" method="post" action="guardarCliente.php" onsubmit="return validateForm()">

        <input id="ID" type="hidden" name="ID"
               value="<?php echo isset($cliente
            ) ? $cliente
            ["ID"] : "" ?>"/>

            
        <input id="ID_EMPLEADO" type="hidden" name="ID_EMPLEADO"
               value="<?php echo isset($empleado) ? $empleado["ID_EMPLEADO"] : 3 ?>"/>

        <label for="NOMBRE">Nombre:</label>
        <input required id="NOMBRE" type="text" name="NOMBRE"
                       value="<?php echo isset($cliente
                    ) ? $cliente
                    ["NOMBRE"] : "" ?>"/>
        <br>
        <label for="APELLIDOS">Apellidos:</label>
        <input required id="APELLIDOS" type="text" name="APELLIDOS"
                          value="<?php echo isset($cliente
                        ) ? $cliente
                        ["APELLIDOS"] : "" ?>"/>
        <br>
        <label for="DNI">DNI:</label>
        <input required id="DNI" type="text" name="DNI" pattern="(\d{8})([A-Z]{1})" placeholder="12345678A"
                    value="<?php echo isset($cliente
                ) ? $cliente
                ["DNI"] : "" ?>"/>
        <br>
        <label for="TELEFONO">Teléfono:</label>
        <input required id="TELEFONO" type="text" name="TELEFONO" placeholder="123456789" pattern="(\d{9})"
                         value="<?php echo isset($cliente
                        ) ? $cliente
                        ["TELEFONO"] : "" ?>"/>
        <br>
        <label for="CORREO">Correo:</label>
        <input required id="CORREO" type="email" name="CORREO" placeholder="ejemplo@dominio.es"
                       value="<?php echo isset($cliente
                    ) ? $cliente
                    ["CORREO"] : "" ?>"/>
        <br>
        <label for="DIRECCION">Dirección:</label>
        <input required id="DIRECCION" type="text" name="DIRECCION"
                        value="<?php echo isset($cliente
                    ) ? $cliente
                    ["DIRECCION"] : "" ?>"/>

        <label for="ID_EMPLEADO">Empleados:</label>
            <select id="ID_EMPLEADO"  name="ID_EMPLEADO">
                       <?php foreach ($listEmpleados as $empleado) { ?>
                            <option  value=" <?php echo isset($empleado) ? $empleado["ID"] : "" ?>"><?php echo $empleado["NOMBRE"]?></option>
                        <?php } ?></select>
     
        
       
        <br>
        <button id="guardar" name="guardar" type="submit" class="guardarEmpleado">Guardar</button>
        <button id="cancelar" name="cancelar" type="submit" formnovalidate class="cancelar">Cancelar</button>
    </form>

</main>
</body>
<?php include_once('../includes/pie.php'); ?>
</html>
