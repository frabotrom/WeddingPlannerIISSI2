<?php
session_start();

include_once("../gestionBD.php");



if(isset($_REQUEST["guardar"])) {

    $conexion = crearConexionBD();




    //Comprobación del id
    if(!isset($_REQUEST["ID"])){
        $excepcion["Error id"] = "No se ha registrado el id del cliente";
    } elseif (!is_numeric((int) $_REQUEST["ID"])){
        $excepcion["Error id"] = "El id no es un número";
    } else {
        $cliente["ID"] = $_REQUEST["ID"];
    }

    //Comprobación del nombre
    if(!isset($_REQUEST["NOMBRE"])){
        $excepcion["Error nombre"] = "No se ha registrado el nombre del cliente";
    } else {
        $cliente["NOMBRE"] = $_REQUEST["NOMBRE"];
    }

    //Comprobación del apellido
    if(!isset($_REQUEST["APELLIDOS"])){
        $excepcion["Error apellidos"] = "No se han registrado los apellidos del cliente";
    } else {
        $cliente["APELLIDOS"] = $_REQUEST["APELLIDOS"];
    }

    //Comprobación del DNI
    if(!isset($_REQUEST["DNI"])){
        $excepcion["Error DNI"] = "No se ha registrado el DNI";
    } elseif(!preg_match("/\d{8}[A-Z]{1}/", $_REQUEST["DNI"])) {
        $excepcion["Error DNI"] = "El DNI no es correcto";
    } else {
        $cliente["DNI"] = $_REQUEST["DNI"];
    }
    $cliente["DNI"] = $_REQUEST["DNI"];

    //Comprobación del teléfono
    if(!isset($_REQUEST["TELEFONO"])){
        $excepcion["Error telefono"] = "No se ha registrado el telefono";
    } elseif(!preg_match("/\d{9}/", $_REQUEST["TELEFONO"])) {
        $excepcion["Error telefono"] = "El teléfono no es correcto";
    } else {
        $cliente["TELEFONO"] = $_REQUEST["TELEFONO"];
    }

    $cliente["TELEFONO"] = $_REQUEST["TELEFONO"];

    //Comprobación del correo
    if(!isset($_REQUEST["CORREO"])){
        $excepcion["Error correo"] = "No se ha registrado el correo";
    } else {
        $cliente["CORREO"] = $_REQUEST["CORREO"];
    }

    //Comprobación de la dirección
    if(!isset($_REQUEST["DIRECCION"])){
        $excepcion["Error dirección"] = "No se ha registrado la dirección";
    } else {
        $cliente["DIRECCION"] = $_REQUEST["DIRECCION"];
    }

    //Comprobación del ID de cliente$cliente
    if(!isset($_REQUEST["ID_EMPLEADO"])){
        $excepcion["Error ID de empleado"] = "No se ha registrado el valor de ID de cliente";
    } else {
        $cliente["ID_EMPLEADO"] = $_REQUEST["ID_EMPLEADO"];
    }

     //Comprobación del ID de cliente$cliente
     if(!isset($_REQUEST["ID_EMPLEADO"])){
        $excepcion["Error ID de empleado"] = "No se ha registrado el valor de ID de cliente";
    } else {
        $cliente["ID_EMPLEADO"] = $_REQUEST["ID_EMPLEADO"];
    }


    if(isset($excepcion)){
        $_SESSION["excepcion"] = $excepcion;
    }

    try {
        //Editar cliente$cliente
        if (isset($_SESSION["cliente"])) {

             $query = "CALL MODIFICAR_CLIENTE(:id,:nombre,:apellidos,:dni,:telefono,:correo,:direccion,:id_empleado)";
             $stmt = $conexion->prepare($query);
             $stmt->bindParam(':id', $cliente["ID"]);
            $stmt->bindParam(':nombre', $cliente["NOMBRE"]);
            $stmt->bindParam(':apellidos', $cliente["APELLIDOS"]);
            $stmt->bindParam(':dni', $cliente["DNI"]);
            $stmt->bindParam(':telefono', $cliente["TELEFONO"]);
            $stmt->bindParam(':correo', $cliente["CORREO"]);
            $stmt->bindParam(':direccion', $cliente["DIRECCION"]);
            $stmt->bindParam(':id_empleado', $cliente["ID_EMPLEADO"]);
            $stmt->execute();
            //Guardar nuevo cliente$cliente
        } else {

            $query = "CALL CREAR_CLIENTE(:nombre, :apellidos, :dni, :telefono, :correo, :direccion, :id_empleado)";

            $stmt = $conexion->prepare($query);
            $stmt->bindParam(':nombre', $cliente["NOMBRE"]);
            $stmt->bindParam(':apellidos', $cliente["APELLIDOS"]);
            $stmt->bindParam(':dni', $cliente["DNI"]);
            $stmt->bindParam(':telefono', $cliente["TELEFONO"]);
            $stmt->bindParam(':correo', $cliente["CORREO"]);
            $stmt->bindParam(':direccion', $cliente["DIRECCION"]);
            $stmt->bindParam(':id_empleado', $cliente["ID_EMPLEADO"]);
            $stmt->execute();
        }

    } catch (PDOException $e) {
        $_SESSION["excepcion"] = $e->GetMessage();

        //TODO: Crear página de error
        $_SESSION['excepcion'] = $e->GetMessage();
//        header("Location: error.php");
    }

    unset($_SESSION["cliente"]);
    cerrarConexionBD($conexion);

}
Header("Location: listCliente.php");
?>