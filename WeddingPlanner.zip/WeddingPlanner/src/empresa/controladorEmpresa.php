<?php
session_start();

if (isset($_REQUEST["editar"])) {

    $empresa["ID"] = $_REQUEST["ID"];
    $empresa["NOMBRE"] = $_REQUEST["NOMBRE"];
    $empresa["TELEFONO"] = $_REQUEST["TELEFONO"];
    $empresa["CORREO"] = $_REQUEST["CORREO"];
    $empresa["DIRECCION"] = $_REQUEST["DIRECCION"];

    $_SESSION["empresa"] = $empresa;

    Header("Location: formEmpresa.php");

} elseif (isset($_REQUEST["borrar"])) {
    $_SESSION["idEmpresa"] = $_REQUEST["ID"];
    Header("Location: borrarEmpresa.php");

} elseif (isset($_REQUEST["crear"])) {
    Header("Location: formEmpresa.php");

} else {
    Header("Location: listEmpresa.php");
}
?>