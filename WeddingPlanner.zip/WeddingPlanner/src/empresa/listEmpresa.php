<?php
session_start();


include_once("../gestionBD.php");
include_once("../gestionPaginacion.php");

unset($_SESSION["empresa"]);

//Se crea la conexión a la BD
$conexion = crearConexionBD();

// Petición a la BD
$query = 'SELECT * FROM empresas ORDER BY id DESC';

$ret = gestionarPaginacion($conexion, $query);

$paginaSeleccionada = $ret["paginaSeleccionada"];
$totalPaginas = $ret["totalPaginas"];
$listEmpresas = $ret["listPaginada"];
$tamPagina = $ret["tamPagina"];
$totalEmpresas = $ret["totalElementos"];

cerrarConexionBD($conexion);
?>

<!DOCTYPE html>
<html lang="es">
<?php include_once('../includes/cabecera.php'); ?>
<?php include_once('../includes/menu.php'); ?>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Wedding Planner</title>
</head>

<body>
<main>
    <div class="row">
        <div class="centercolumn">
            <div class="card">
                <form method="post" action="controladorEmpresa.php" style="display: flex">
                    <h3>Empresas</h3>
                    <button id="crear" name="crear" type="submit" class="crearFila">
                        <img src="../../images/suma.png" class="crearFila" alt="Crear empresa" width="25"
                             height="25">
                    </button>
                </form>

                <nav>

                    <div id="paginacion">

                        <?php

                        for ($pagina = 1; $pagina <= $totalPaginas; $pagina++) {

                            if ($pagina == $paginaSeleccionada) { ?>

                                <span class="current"><?php echo $pagina; ?></span>

                            <?php } else { ?>

                                <a href="listEmpresa.php?numPagina=<?php echo $pagina; ?>&tamPagina=<?php echo $tamPagina;; ?>"><?php echo $pagina; ?></a>

                            <?php } ?>
                        <?php } ?>

                    </div>


                    <form method="get" action="listEmpresa.php">

                        <input id="numPagina" name="numPagina" type="hidden" value="<?php echo $paginaSeleccionada ?>"/>

                        Mostrando

                        <input id="tamPagina" name="tamPagina" type="number"

                               min="1" max="<?php echo $totalEmpresas ?>"

                               value="<?php echo $totalEmpresas < 5 ? $totalEmpresas : $tamPagina ?>" autofocus="autofocus"/>

                        entradas de <?php echo $totalEmpresas ?>

                        <input type="submit" value="Cambiar">

                    </form>

                </nav>

                <table width="100%">

                    <tr>
                        <th>Nombre</th>
                        <th>Teléfono</th>
                        <th>Correo</th>
                        <th>Dirección</th>
                    </tr>

                    <?php

                    foreach ($listEmpleados as $empresa) {

                        ?>
                        <tr>
                            <td><?php echo $empresa["NOMBRE"] . " " . $empresa["APELLIDOS"] ?></td>
                            <td><?php echo $empresa["TELEFONO"] ?></td>
                            <td><?php echo $empresa["CORREO"] ?></td>
                            <td><?php echo $empresa["DIRECCION"] ?></td>

                            <td>
                                <form method="post" action="controladorEmpresa.php">

                                    <input id="ID" name="ID" type="hidden"
                                           value="<?php echo $empresa["ID"] ?>">

                                    <input id="NOMBRE" name="NOMBRE" type="hidden"
                                           value="<?php echo $empresa["NOMBRE"] ?>">

                                    <input id="TELEFONO" name="TELEFONO" type="hidden"
                                           value="<?php echo $empresa["TELEFONO"] ?>">

                                    <input id="CORREO" name="CORREO" type="hidden"
                                           value="<?php echo $empresa["CORREO"] ?>">

                                    <input id="USUARIO" name="USUARIO" type="hidden"
                                           value="<?php echo $empresa["DIRECCION"] ?>">

                                    <button id="editar" name="editar" type="submit" class="editarFila">
                                        <img src="../../images/lapiz.png" class="editarFila" alt="Editar empresa" width="25"
                                             height="25">
                                    </button>

                                    <button id="borrar" name="borrar" type="submit" class="borrarFila">
                                        <img src="../../images/papelera.png" class="borrarFila" alt="Borrar empresa" width="25"
                                             height="25">
                                    </button>

                                </form>
                            </td>
                        </tr>
                    <?php } ?>
                </table>

                <?php
                if(isset($_SESSION["excepcion"])) {
                    foreach ($_SESSION["excepcion"] as $e){
                        echo $e;
                    }
                    unset($_SESSION["excepcion"]);
                }
                ?>
            </div>
</main>
</body>
<?php include('../includes/pie.php'); ?>
</html>
