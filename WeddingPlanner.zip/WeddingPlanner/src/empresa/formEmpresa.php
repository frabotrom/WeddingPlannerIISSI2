<?php
session_start();

include_once("../gestionBD.php");
include_once("../gestionPaginacion.php");
$conexion = crearConexionBD();

$queryEmpleados = 'SELECT * FROM empleados ORDER BY id DESC';

$ret = gestionarPaginacion($conexion, $queryEmpleados);

$paginaSeleccionada = $ret["paginaSeleccionada"];
$totalPaginas = $ret["totalPaginas"];
$listEmpleados = $ret["listPaginada"];
$tamPagina = $ret["tamPagina"];
$totalEmpleados= $ret["totalElementos"];



if (isset($_SESSION["cliente"]))
    $cliente = $_SESSION["cliente"];
cerrarConexionBD($conexion);

?>

<!DOCTYPE html>
<html lang="es">
<?php include_once('../../includes/cabecera.php'); ?>
<?php include_once('../../includes/menu.php'); ?>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Wedding Planner</title>

    <script src="validacionFormulario.js"></script>
</head>

<body>

<main>
    <div class="row">
        <div class="centercolumn">
            <div class="card">
                <form name="formEmpresa" method="post" action="guardarEmpresa.php" onsubmit="return validateForm()">

                    <input id="ID" type="hidden" name="ID"
                           value="<?php echo isset($empresa) ? $empresa["ID"] : "" ?>"/>

                    <label for="NOMBRE">Nombre:</label>
                    <input required id="NOMBRE" type="text" name="NOMBRE"
                           value="<?php echo isset($empresa) ? $empresa["NOMBRE"] : "" ?>"/>
                    <br>
                    <label for="TELEFONO">Teléfono:</label>
                    <input required id="TELEFONO" type="text" name="TELEFONO" placeholder="123456789" pattern="(\d{9})"
                           value="<?php echo isset($empresa) ? $empresa["TELEFONO"] : "" ?>"/>
                    <br>
                    <label for="CORREO">Correo:</label>
                    <input required id="CORREO" type="email" name="CORREO" placeholder="ejemplo@dominio.es"
                           value="<?php echo isset($empresa) ? $empresa["CORREO"] : "" ?>"/>
                    <br>
                    <label for="DIRECCION">Dirección:</label>
                    <input required id="DIRECCION" type="text" name="DIRECCION" placeholder="Avd Andalucía Nº4 Local 2"
                           value="<?php echo isset($empresa) ? $empresa["DIRECCION"] : "" ?>"/>
                    <br>
                    <button id="guardar" name="guardar" type="submit" class="guardarEmpresa">Guardar</button>
                    <button id="cancelar" name="cancelar" type="submit" formnovalidate class="cancelar">Cancelar</button>
                </form>

</main>
</body>
<?php include('../../includes/pie.php'); ?>
</html>