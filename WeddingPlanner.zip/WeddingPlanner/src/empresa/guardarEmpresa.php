<?php
session_start();

include_once("../gestionBD.php");
if(isset($_REQUEST["guardar"])) {

    $conexion = crearConexionBD();

    //Comprobación del id
    if(!isset($_REQUEST["ID"])){
        $excepcion["Error id"] = "No se ha registrado el id de la empresa";
    } elseif (!is_numeric((int) $_REQUEST["ID"])){
        $excepcion["Error id"] = "El id no es un número";
    } else {
        $empresa["ID"] = $_REQUEST["ID"];
    }

    //Comprobación del nombre
    if(!isset($_REQUEST["NOMBRE"])){
        $excepcion["Error nombre"] = "No se ha registrado el nombre de la empresa";
    } else {
        $empleado["NOMBRE"] = $_REQUEST["NOMBRE"];
    }

    //Comprobación del teléfono
    if(!isset($_REQUEST["TELEFONO"])){
        $excepcion["Error telefono"] = "No se ha registrado el telefono";
    } elseif(!preg_match("/\d{9}/", $_REQUEST["TELEFONO"])) {
        $excepcion["Error telefono"] = "El teléfono no es correcto";
    } else {
        $empresa["TELEFONO"] = $_REQUEST["TELEFONO"];
    }

    //Comprobación del correo
    if(!isset($_REQUEST["CORREO"])){
        $excepcion["Error correo"] = "No se ha registrado el correo";
    } else {
        $empresa["CORREO"] = $_REQUEST["CORREO"];
    }

    //Comprobación de la dirección
    if(!isset($_REQUEST["DIRECCION"])){
        $excepcion["Error direccion"] = "No se ha registrado la dirección";
    } else {
        $empresa["DIRECCION"] = $_REQUEST["DIRECCION"];
    }

    try {
        //Editar empresa
        if (isset($_SESSION["empresa"])) {

            $query = "CALL MODIFICAR_EMPRESA(:id,:nombre,:telefono,:correo,:direccion)";

            $stmt = $conexion->prepare($query);
            $stmt->bindParam(':id', $empresa["ID"]);
            $stmt->bindParam(':nombre', $empresa["NOMBRE"]);
            $stmt->bindParam(':telefono', $empresa["TELEFONO"]);
            $stmt->bindParam(':correo', $empresa["CORREO"]);
            $stmt->bindParam(':direccion', $empresa["DIRECCION"]);
            $stmt->execute();

            //Guardar nueva empresa
        } else {

            $query = "CALL CREAR_EMPRESA(:nombre, :telefono, :correo, :direccion)";

            $stmt = $conexion->prepare($query);
            $stmt->bindParam(':id', $empresa["ID"]);
            $stmt->bindParam(':nombre', $empresa["NOMBRE"]);
            $stmt->bindParam(':telefono', $empresa["TELEFONO"]);
            $stmt->bindParam(':correo', $empresa["CORREO"]);
            $stmt->bindParam(':direccion', $empresa["DIRECCION"]);
            $stmt->execute();
        }

    } catch (PDOException $e) {
        $_SESSION["excepcion"] = $e->GetMessage();

        //TODO: Crear página de error
        $_SESSION['excepcion'] = $e->GetMessage();
//        header("Location: error.php");
    }

    unset($_SESSION["empresa"]);
    cerrarConexionBD($conexion);

}
Header("Location: listEmpresa.php");
?>