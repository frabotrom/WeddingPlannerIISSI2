<?php
session_start();

include_once("../gestionBD.php");

if (isset($_SESSION["idEmpresa"])) {
    try {
        $conexion = crearConexionBD();

        $query = "CALL ELIMINAR_EMPRESA(:id)";

        $stmt = $conexion->prepare($query);
        $stmt->bindParam(":id", $_SESSION["idEpresa"]);
        $stmt->execute();
    } catch (PDOException $e){
        $_SESSION["excepcion"] = $e->getMessage();
        //Header("Location: error.php");
    }

    unset($_SESSION["idEmpresa"]);
    cerrarConexionBD($conexion);
}

Header("Location: listEmpresa.php");
?>