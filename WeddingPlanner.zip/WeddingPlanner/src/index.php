<?php
session_start();

if(isset($_SESSION["empleado"]))
    $empleado = $_SESSION["empleado"];
?>
<!DOCTYPE html>
<html>
<head>
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            font-family: Arial;
            padding: 10px;
            background: linear-gradient(#dad7a2, #c0bd8b);
        }

        /* Header/Blog Title */
        .header {
            padding: 20px;
            text-align: center;
            background: #000000 url(../images/banner.jpg) 100% 100% no-repeat;
        }

        .header h1 {
            font-size: 50px;
        }

        /* Style the top navigation bar */
        .topnav {
            overflow: hidden;
            background-color: #333;
        }

        /* Style the topnav links */
        .topnav a {
            float: left;
            display: block;
            color: #f2f2f2;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        /* Change color on hover */
        .topnav a:hover {
            background-color: #ddd;
            color: black;
        }

        /* Create two unequal columns that floats next to each other */
        /* Left column */
        .leftcolumn {
            float: left;
            width: 75%;
        }

        /* Right column */
        .rightcolumn {
            float: left;
            width: 25%;
            background-color: #f1f1f1;
            padding-left: 20px;
        }

        /* Add a card effect for articles */
        .card {
            background-color: whitesmoke;
            padding: 20px;
            margin-top: 20px;
        }

        /* Clear floats after the columns */
        .row:after {
            content: "";
            display: table;
            clear: both;
        }

        /* Footer */
        .footer {
            padding: 20px;
            text-align: center;
            background: #ddd;
            margin-top: 20px;
        }

        /* Responsive layout - when the screen is less than 800px wide, make the two columns stack on top of each other instead of next to each other */
        @media screen and (max-width: 800px) {
            .leftcolumn, .rightcolumn {
                width: 100%;
                padding: 0;
            }
        }

        /* Responsive layout - when the screen is less than 400px wide, make the navigation links stack on top of each other instead of next to each other */
        @media screen and (max-width: 400px) {
            .topnav a {
                float: none;
                width: 100%;
            }
        }
    </style>
</head>
<body>

<div class="header">
    <h1>Wedding Planner</h1>
    <p>Tu organizador de bodas personal.</p>
</div>

<div class="topnav">
    <a href="#">Clientes</a>
    <a href="#">Eventos</a>
    <a href="#">Servicios</a>
    <a href="#">Empresas</a>
</div>

<div class="row">
    <div class="centercolumn">
        <div class="card">
            <form method="post" action="guardarEmpleado.php">

                <input id="ID" type="hidden" name="ID"
                       value="<?php echo isset($empleado) ? $empleado["ID"] : ""?>"/>

                Nombre: <input required id="NOMBRE" type="text" name="NOMBRE"
                               value="<?php echo isset($empleado) ? $empleado["NOMBRE"] : ""?>"/>
                <br>
                Apellidos: <input required id="APELLIDOS" type="text" name="APELLIDOS"
                                  value="<?php echo isset($empleado) ? $empleado["APELLIDOS"] : ""?>"/>
                <br>
                DNI: <input required id="DNI" type="text" name="DNI" pattern="(\d{8})([A-Z]{1})" placeholder="12345678A"
                            value="<?php echo isset($empleado) ? $empleado["DNI"] : ""?>"/>
                <br>
                Teléfono: <input required id="TELEFONO" type="text" name="TELEFONO" placeholder="123456789"
                                 value="<?php echo isset($empleado) ? $empleado["TELEFONO"] : ""?>"/>
                <br>
                Correo: <input required id="CORREO" type="email" name="CORREO" placeholder="ejemplo@dominio.es"
                               value="<?php echo isset($empleado) ? $empleado["CORREO"] : ""?>"/>
                <br>
                Usuario: <input required id="USUARIO" type="text" name="USUARIO"
                                value="<?php echo isset($empleado) ? $empleado["USUARIO"] : ""?>"/>
                <br>
                Contraseña: <input required id="CONTRASENA" type="password" name="CONTRASENA"
                                   value="<?php echo isset($empleado) ? $empleado["CONTRASENA"] : ""?>"/>
                <br>
                Vuelva a introducir la contraseña: <input required id="CONTRASENA2" type="password" name="CONTRASENA2"
                                                          value="<?php echo isset($empleado) ? $empleado["CONTRASENA"] : ""?>"/>
                <br>
                <button id="guardar" name="guardar" type="submit" class="guardarEmpleado">Guardar</button>
                <button id="cancelar" name="cancelar" type="submit" formnovalidate class="cancelar">Cancelar</button>
            </form>
        </div>
        <div class="card">
            <h2>TITLE HEADING</h2>
            <h5>Title description, Sep 2, 2017</h5>
            <div class="fakeimg" style="height:200px;">Image</div>
            <p>Some text..</p>
            <p>Sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>
        </div>
</div>

<div class="footer">
    <h2>Footer</h2>
</div>

</body>