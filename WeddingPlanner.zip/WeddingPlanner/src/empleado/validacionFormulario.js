function validateForm() {
    console.log("Prueba de contraseñas");
    var existErrors = false;
    var form = document.forms["formEmpleado"];

    //Validación: Ambas contraseñas deben ser iguales
    var contrasena = form["CONTRASENA"];
    var contrasena2 = form["CONTRASENA2"];
    var spanContrasena = document.getElementById("spanContrasena");

    if(contrasena.value != contrasena2.value) {
        existErrors = true;
        spanContrasena.className = "error";
        spanContrasena.innerHTML = "Las contraseñas deben coincidir";
    }

    return !existErrors;
}