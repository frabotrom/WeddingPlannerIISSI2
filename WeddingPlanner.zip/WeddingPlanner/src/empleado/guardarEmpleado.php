<?php
session_start();

include_once("../gestionBD.php");
if(isset($_REQUEST["guardar"])) {

    $conexion = crearConexionBD();

    //Comprobación del id
    if(!isset($_REQUEST["ID"])){
        $excepcion["Error id"] = "No se ha registrado el id del empleado";
    } elseif (!is_numeric((int) $_REQUEST["ID"])){
        $excepcion["Error id"] = "El id no es un número";
    } else {
        $empleado["ID"] = $_REQUEST["ID"];
    }

    //Comprobación del nombre
    if(!isset($_REQUEST["NOMBRE"])){
        $excepcion["Error nombre"] = "No se ha registrado el nombre del empleado";
    } else {
        $empleado["NOMBRE"] = $_REQUEST["NOMBRE"];
    }

    //Comprobación del apellido
    if(!isset($_REQUEST["APELLIDOS"])){
        $excepcion["Error apellidos"] = "No se han registrado los apellidos del empleado";
    } else {
        $empleado["APELLIDOS"] = $_REQUEST["APELLIDOS"];
    }

    //Comprobación del DNI
    if(!isset($_REQUEST["DNI"])){
        $excepcion["Error DNI"] = "No se ha registrado el DNI";
    } elseif(!preg_match("/\d{8}[A-Z]{1}/", $_REQUEST["DNI"])) {
        $excepcion["Error DNI"] = "El DNI no es correcto";
    } else {
        $empleado["DNI"] = $_REQUEST["DNI"];
    }
    $empleado["DNI"] = $_REQUEST["DNI"];

    //Comprobación del teléfono
    if(!isset($_REQUEST["TELEFONO"])){
        $excepcion["Error telefono"] = "No se ha registrado el telefono";
    } elseif(!preg_match("/\d{9}/", $_REQUEST["TELEFONO"])) {
        $excepcion["Error telefono"] = "El teléfono no es correcto";
    } else {
        $empleado["TELEFONO"] = $_REQUEST["TELEFONO"];
    }

    $empleado["TELEFONO"] = $_REQUEST["TELEFONO"];

    //Comprobación del correo
    if(!isset($_REQUEST["CORREO"])){
        $excepcion["Error correo"] = "No se ha registrado el correo";
    } else {
        $empleado["CORREO"] = $_REQUEST["CORREO"];
    }

    //Comprobación del usuario
    if(!isset($_REQUEST["USUARIO"])){
        $excepcion["Error usuario"] = "No se ha registrado el correo";
    } else {
        $empleado["USUARIO"] = $_REQUEST["USUARIO"];
    }

    //Comprobación del contraseña
    if(!isset($_REQUEST["CONTRASENA"])){
        $excepcion["Error contrasena"] = "No se ha registrado la contraseña";
    } elseif ($_REQUEST["CONTRASENA"] != $_REQUEST["CONTRASENA2"]) {
        $excepcion["Error contrasena"] = "Las contraseás no coinciden";
    } else {
        $empleado["CONTRASENA"] = $_REQUEST["CONTRASENA"];
    }

    //Comprobación del es administrador
    if(!isset($_REQUEST["ES_ADMINISTRADOR"])){
        $excepcion["Error es_administrador"] = "No se ha registrado el valor de es_administrador";
    } else {
        $empleado["ES_ADMINISTRADOR"] = $_REQUEST["ES_ADMINISTRADOR"];
    }

    if(isset($excepcion)){
        $_SESSION["excepcion"] = $excepcion;
    }

    try {
        //Editar empleado
        if (isset($_SESSION["empleado"])) {

            $query = "CALL MODIFICAR_EMPLEADO(:id,:nombre,:apellidos,:dni,:telefono,:correo,:usuario,:contrasena,0)";

            $stmt = $conexion->prepare($query);
            $stmt->bindParam(':id', $empleado["ID"]);
            $stmt->bindParam(':nombre', $empleado["NOMBRE"]);
            $stmt->bindParam(':apellidos', $empleado["APELLIDOS"]);
            $stmt->bindParam(':dni', $empleado["DNI"]);
            $stmt->bindParam(':telefono', $empleado["TELEFONO"]);
            $stmt->bindParam(':correo', $empleado["CORREO"]);
            $stmt->bindParam(':usuario', $empleado["USUARIO"]);
            $stmt->bindParam(':contrasena', $empleado["CONTRASENA"]);
            $stmt->execute();

            //Guardar nuevo empleado
        } else {

            $query = "CALL CREAR_EMPLEADO(:nombre, :apellidos, :dni, :telefono, :correo, :usuario, :contrasena, 0)";

            $stmt = $conexion->prepare($query);
            $stmt->bindParam(':nombre', $empleado["NOMBRE"]);
            $stmt->bindParam(':apellidos', $empleado["APELLIDOS"]);
            $stmt->bindParam(':dni', $empleado["DNI"]);
            $stmt->bindParam(':telefono', $empleado["TELEFONO"]);
            $stmt->bindParam(':correo', $empleado["CORREO"]);
            $stmt->bindParam(':usuario', $empleado["USUARIO"]);
            $stmt->bindParam(':contrasena', $empleado["CONTRASENA"]);
            $stmt->execute();
        }

    } catch (PDOException $e) {
        $_SESSION["excepcion"] = $e->GetMessage();

        //TODO: Crear página de error
        $_SESSION['excepcion'] = $e->GetMessage();
//        header("Location: error.php");
    }

    unset($_SESSION["empleado"]);
    cerrarConexionBD($conexion);

}
Header("Location: listEmpleado.php");
?>