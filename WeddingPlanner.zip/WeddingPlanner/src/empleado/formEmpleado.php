<?php
session_start();

if (isset($_SESSION["empleado"]))
    $empleado = $_SESSION["empleado"];
?>

<!DOCTYPE html>
<html lang="es">
<?php include_once('../../includes/cabecera.php'); ?>
<?php include_once('../../includes/menu.php'); ?>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Wedding Planner</title>

    <script src="validacionFormulario.js"></script>
</head>

<body>

<main>
    <div class="row">
        <div class="centercolumn">
            <div class="card">
    <form name="formEmpleado" method="post" action="guardarEmpleado.php" onsubmit="return validateForm()">

        <input id="ID" type="hidden" name="ID"
               value="<?php echo isset($empleado) ? $empleado["ID"] : "" ?>"/>

        <input id="ES_ADMINISTRADOR" type="hidden" name="ES_ADMINISTRADOR"
               value="<?php echo isset($empleado) ? $empleado["ES_ADMINISTRADOR"] : 0 ?>"/>

        <label for="NOMBRE">Nombre:</label>
        <input required id="NOMBRE" type="text" name="NOMBRE"
                       value="<?php echo isset($empleado) ? $empleado["NOMBRE"] : "" ?>"/>
        <br>
        <label for="APELLIDOS">Apellidos:</label>
        <input required id="APELLIDOS" type="text" name="APELLIDOS"
                          value="<?php echo isset($empleado) ? $empleado["APELLIDOS"] : "" ?>"/>
        <br>
        <label for="DNI">DNI:</label>
        <input required id="DNI" type="text" name="DNI" pattern="(\d{8})([A-Z]{1})" placeholder="12345678A"
                    value="<?php echo isset($empleado) ? $empleado["DNI"] : "" ?>"/>
        <br>
        <label for="TELEFONO">Teléfono:</label>
        <input required id="TELEFONO" type="text" name="TELEFONO" placeholder="123456789" pattern="(\d{9})"
                         value="<?php echo isset($empleado) ? $empleado["TELEFONO"] : "" ?>"/>
        <br>
        <label for="CORREO">Correo:</label>
        <input required id="CORREO" type="email" name="CORREO" placeholder="ejemplo@dominio.es"
                       value="<?php echo isset($empleado) ? $empleado["CORREO"] : "" ?>"/>
        <br>
        <label for="USUARIO">Usuario:</label>
        <input required id="USUARIO" type="text" name="USUARIO"
                        value="<?php echo isset($empleado) ? $empleado["USUARIO"] : "" ?>"/>
        <br>
        <label for="CONTRASENA">Contraseña:</label>
        <input required id="CONTRASENA" type="password" name="CONTRASENA" placeholder="Insertar contraseña"
               value="<?php echo isset($empleado) ? $empleado["CONTRASENA"] : "" ?>"/>
        <span id="spanContrasena"></span>
        <br>
        <label for="CONTRASENA2">Vuelva a introducir la contraseña:</label>
        <input required id="CONTRASENA2" type="password" name="CONTRASENA2" placeholder="Insertar contraseña"
               value="<?php echo isset($empleado) ? $empleado["CONTRASENA"] : "" ?>"/>
        <br>
        <button id="guardar" name="guardar" type="submit" class="guardarEmpleado">Guardar</button>
        <button id="cancelar" name="cancelar" type="submit" formnovalidate class="cancelar">Cancelar</button>
    </form>

</main>
</body>
<?php include('../../includes/pie.php'); ?>
</html>
